 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.0
*/

/*
� [2023] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"

#define TEST_MODE                               0       // 0 = Uses I3C base layer; 1 = Uses internal simulated data
#define USE_PHY_ADDR_FOR_CRC8                   0       // 0 = Skips adding physical addr to CRC8 calculation

#define TestTimer_Start                         TU16A_Start
#define TestTimer_Stop                          TU16A_Stop

#define CRC8_POLY                               0x07
#define CRC8_LEN                                7

#define CRC32C_POLY                             0x1EDC6F41
#define CRC32C_LEN                              31

#define DEFAULT_LINE_LENGTH                     16

#define MCTP_MAX_PACKET_SIZE                    64      // Should be min 64 as per MCTP spec
#define MCTP_PACKET_OVERHEAD                    5       // 4 bytes header + 1 byte PEC
#define MCTP_MAX_MESSAGE_SIZE                   512
#define MCTP_PHY_ADDR                           0x08    // Use MCTP_I3C_AddressGet() instead of this

// States for Reception State Machine
enum MCTP_STATE_RECEPTION {
    STATE_RX_START = 1,             // Start state when no reception is in progress
    STATE_RX_PACKET_RECEIVE_WAIT,   // State while waiting to receive packets from Primary
    STATE_RX_PACKET_DECODE,         // Decode packet headers and payload
    STATE_RX_MESSAGE_ASSEMBLE,      // Assemble message from one or more packet payloads
    STATE_RX_MESSAGE_DECIPHER,      // Decipher message headers and data
    STATE_RX_ACTION,                // Take action based on message data
    STATE_RX_ERROR                  // Generic error state
};

// States for Transmission State Machine
enum MCTP_STATE_TRANSMISSION {
    STATE_TX_START = 1,             // Idle state when no transmission is in progress
    STATE_TX_MESSAGE_PACKAGE,       // Package message based on message data
    STATE_TX_MESSAGE_BREAKDOWN,     // Break down message into packets
    STATE_TX_PACKET_ENCODE,         // Encode packets into transport format
    STATE_TX_PACKET_SEND,           // Send raw packets over I3C
    STATE_TX_PACKET_SEND_WAIT,      // State while waiting for Primary to read the packet
    STATE_TX_PACKET_DISCARD,        // Temporary state to discard transport packet
    STATE_TX_ACTION,                // Take follow up action after packet is sent
    STATE_TX_ERROR                  // Generic error state
};

// Error Conditions
enum MCTP_ERROR {
    SUCCESS = 1,
    IN_PROGRESS,                    // Generic in progress - like for message assembly/breakdown in progress
    ERROR,                          // Generic error - do not use if more specific error is available
    ERROR_PACKET_INVALID,           // Packet is not formatted properly
    ERROR_PACKET_UNEXPECTED,        // Unexpected packet received during assembly
    ERROR_PACKET_UNAVAILABLE,       // Packet is being used and not available
    ERROR_MSG_SIZE_EXCEEDED,        // Max message size exceeded during assembly
    ERROR_MSG_UNAVAILABLE,          // Message is being used and not available
    ERROR_MSG_INVALID,              // Message token is invalid
    ERROR_INCORRECT_CRC,            // CRC mismatch for packet or message
    ERROR_I3C_RECEIVE,              // Error during I3C receive
    ERROR_I3C_TRANSMIT,             // Error during I3C transmit
    ERROR_I3C_HOTJOIN               // Error during I3C Hot-Join
};

// Global variables

bool mctp_transmission_begin = false;
bool mctp_reception_begin = true;

// Transport packet is in the format that is sent/received through the physical layer (e.g. I3C)
struct transport_packet {
    uint8_t     packetBuffer[MCTP_MAX_PACKET_SIZE+MCTP_PACKET_OVERHEAD+1];  // +1 to increase size of buffer for proper I3C reception
    uint16_t    packetBufferLength;
    
    // Internal variables
    bool        firstPacket;        // Used when sending packet
    bool        lastPacket;         // Used when sending packet
    bool        packetEmpty;        // True = Packet is fresh and empty; False = packet is being used/dirty
} rxTransportPacket, txTransportPacket;

// Properly formatted individual MCTP packets
struct mctp_packet {
    uint8_t     headerVersion;
    uint8_t     destinationEID;
    uint8_t     sourceEID;
    bool        startOfMessage;
    bool        endOfMessage;
    uint8_t     packetSequence;
    uint8_t     tagOwner;
    uint8_t     messageTag;
    uint8_t     packetPayload[MCTP_MAX_PACKET_SIZE];
    uint16_t    packetPayloadLength;
    uint8_t     crc8Value;
    
    // Internal variables
    bool        packetEmpty;            // True = Packet is fresh and empty; False = packet is being used/dirty
} receivedPacket, transmitPacket;

// Properly formatted complete MCTP message
struct mctp_message {
    uint8_t     headerVersion;
    uint8_t     destinationEID;
    uint8_t     sourceEID;
    uint8_t     tagOwner;
    uint8_t     messageTag;
    uint8_t     messageType;
    bool        integrityCheck;
    uint8_t     messageBody[MCTP_MAX_MESSAGE_SIZE];
    uint16_t    messageBodyLength;
    uint32_t    crc32Value;
    
    // Internal variables
    bool        assemblyInProgress;     // True = message assembly in progress; False = message assembly completed or not started
    uint8_t     lastPacketSequence;     // packet seq number of last packet received/sent -- to keep track of out of seq packets
    bool        breakdownInProgress;    // True = message breakdown in progress; False = message breakdown completed or not started
    bool        messageEmpty;           // True = message is fresh and empty; False = message is being used/dirty
    uint16_t    nextMessageBodyIndex;   // next location in the message body to copy data from into the packet
} rxMessage, txMessage;

// Global state variables for RX and TX state machines
struct mctp_stateMachine_rx {
    enum MCTP_STATE_RECEPTION currentState;
    enum MCTP_STATE_RECEPTION nextState;
    enum MCTP_STATE_RECEPTION previousState;
    bool changeState;
} mctp_rx_state;

struct mctp_stateMachine_tx {
    enum MCTP_STATE_TRANSMISSION currentState;
    enum MCTP_STATE_TRANSMISSION nextState;
    enum MCTP_STATE_TRANSMISSION previousState;
    bool changeState;
} mctp_tx_state;

struct mctp_flags {
    bool        packetReceived;
} mctp_flags;

// Function to print generic buffer
void printBuffer(uint8_t *buffer, uint16_t bufferLength) {
    printf("\t[PRINT BUFFER] Printing %d bytes...\r\n", bufferLength);
    
    uint16_t bufferIndex = 0;
    uint8_t lineIndex = 0;

    while(bufferIndex < bufferLength) {
        printf("\t\t[%d]\t", bufferIndex);
        while(lineIndex < DEFAULT_LINE_LENGTH) {
            if(bufferIndex < bufferLength) {
                printf("%02hhX ", buffer[bufferIndex++]);
            }
            lineIndex++;
        }
        printf("\r\n");
        lineIndex = 0;
    }
}

// Function to initialize generic buffer
void initializeBuffer(uint8_t *buffer, uint16_t bufferLength, uint8_t seedValue, uint8_t increment) {
    //printf("[INIT_BUFFER] Initializing %d bytes from value 0x%02hhX increment %d...\r\n", bufferLength, seedValue, increment);
    
    uint16_t bufferIndex = 0;
    while(bufferIndex < bufferLength) {
        buffer[bufferIndex++] = seedValue;
        seedValue += increment;
    }
    
    // Print initialized buffer (optional)
    //printBuffer(buffer, bufferLength);
}

// Function to print packet
void printPacket(struct mctp_packet *packet) {
    printf("\t[PRINT PACKET]\r\n");
    printf("\t\tHeader Version:   %02hhX\r\n", packet->headerVersion);
    printf("\t\tDestination EID:  %02hhX\r\n", packet->destinationEID);
    printf("\t\tSource EID:       %02hhX\r\n", packet->sourceEID);
    printf("\t\tStart of Message: %02hhX\r\n", packet->startOfMessage);
    printf("\t\tEnd of Message:   %02hhX\r\n", packet->endOfMessage);
    printf("\t\tPacket Sequence:  %02hhX\r\n", packet->packetSequence);
    printf("\t\tTag Owner:        %02hhX\r\n", packet->tagOwner);
    printf("\t\tMessage Tag:      %02hhX\r\n", packet->messageTag);
    printf("\t\tCRC-8 Value:      %02hhX\r\n", packet->crc8Value);
    printf("\t\tPayload Length:   %d\r\n"    , packet->packetPayloadLength);
    printf("\t\tPayload:          \r\n");
    printBuffer(packet->packetPayload, packet->packetPayloadLength);
}

// Function to print message
void printMessage(struct mctp_message *message) {
    printf("\t[PRINT ASSEMBLED MESSAGE]\r\n");
    printf("\t\tHeader Version:   %02hhX\r\n", message->headerVersion);
    printf("\t\tDestination EID:  %02hhX\r\n", message->destinationEID);
    printf("\t\tSource EID:       %02hhX\r\n", message->sourceEID);
    printf("\t\tTag Owner:        %02hhX\r\n", message->tagOwner);
    printf("\t\tMessage Tag:      %02hhX\r\n", message->messageTag);
    printf("\t\tMessage Type:     %02hhX\r\n", message->messageType);
    printf("\t\tIntegrity Check:  %02hhX\r\n", message->integrityCheck);
    printf("\t\tCRC-32 Value:     %08lX\r\n" , message->crc32Value);
    printf("\t\tMessage Length:   %d\r\n"    , message->messageBodyLength);
    printf("\t\tMessage:          \r\n");
    printBuffer(message->messageBody, message->messageBodyLength);
}

/******************************************************************************/
/*************************** MCTP SERVICE ROUTINES ****************************/
/******************************************************************************/

bool MCTP_I3C_HotJoinErrorGet(void)
{
    bool status = I3C1ERRIR0bits.HJEIF;
    I3C1ERRIR0bits.HJEIF = 0;
    return status;
}

uint8_t MCTP_I3C_AddressGet(void)
{
    return I3C1DADR;
}

void MCTP_I3C_IBIRequestNoPayload(void)
{
    // MDB and PSZ are already configured
    // Simply set IBIREQ here
    // Error checking can be performed which is not included here
    I3C1CON0bits.IBIREQ = 1;
}

uint16_t MCTP_TransmissionSizeGet(void)
{
    // return the value of I3CxMRL (or I3CxMWL)

    #if TEST_MODE
    return MCTP_MAX_PACKET_SIZE;
    #else
    return (MCTP_I3C_MaxReadLengthGet() - MCTP_PACKET_OVERHEAD);
    #endif
}

// Function to calculate CRC
uint8_t MCTP_CalculateCRC8(uint8_t *buffer, uint16_t length)
{
    CRC_Initialize(CRC8_LEN, CRC8_POLY);
    CRC_StartCrc();
    
    #if USE_PHY_ADDR_FOR_CRC8
    while(CRC_IsCrcBusy());
    CRC_WriteData((MCTP_I3C_AddressGet() << 1) & 0xFF);
    #endif
    
    for(uint16_t i=0; i < length; i++) {
        while(CRC_IsCrcBusy());
        CRC_WriteData(buffer[i]);
    }
    
    return CRC_GetCalculatedResult(false, 0);
}

#if TEST_MODE

// TEST PACKET AND INITIALIZATION
struct transport_packet test_5pkt_64B_good[5];
void test_5pkt_64B_good_initialize()
{
    // Packet 1
    test_5pkt_64B_good[0].packetBufferLength = 69;
    test_5pkt_64B_good[0].packetBuffer[0]   = 0x02;     // Header
    test_5pkt_64B_good[0].packetBuffer[1]   = 0x33;     // Dest EID
    test_5pkt_64B_good[0].packetBuffer[2]   = 0x44;     // Src EID
    test_5pkt_64B_good[0].packetBuffer[3]   = 0x8E;     // SOM/EOM/TO/Tag
    test_5pkt_64B_good[0].packetBuffer[4]   = 0x84;     // IC/Type -- only for 1st packet
    initializeBuffer(&test_5pkt_64B_good[0].packetBuffer[5], 63, 0x11, 1);  // Payload
    test_5pkt_64B_good[0].packetBuffer[68]  = MCTP_CalculateCRC8(test_5pkt_64B_good[0].packetBuffer, 68);    // PEC CRC-8
    
    // Packet 2
    test_5pkt_64B_good[1].packetBufferLength = 69;
    test_5pkt_64B_good[1].packetBuffer[0]   = 0x02;     // Header
    test_5pkt_64B_good[1].packetBuffer[1]   = 0x33;     // Dest EID
    test_5pkt_64B_good[1].packetBuffer[2]   = 0x44;     // Src EID
    test_5pkt_64B_good[1].packetBuffer[3]   = 0x1E;     // SOM/EOM/TO/Tag
    initializeBuffer(&test_5pkt_64B_good[1].packetBuffer[4], 64, 0x22, 1);  // Payload
    test_5pkt_64B_good[1].packetBuffer[68]  = MCTP_CalculateCRC8(test_5pkt_64B_good[1].packetBuffer, 68);     // PEC CRC-8
    
    // Packet 3
    test_5pkt_64B_good[2].packetBufferLength = 69;
    test_5pkt_64B_good[2].packetBuffer[0]   = 0x02;     // Header
    test_5pkt_64B_good[2].packetBuffer[1]   = 0x33;     // Dest EID
    test_5pkt_64B_good[2].packetBuffer[2]   = 0x44;     // Src EID
    test_5pkt_64B_good[2].packetBuffer[3]   = 0x2E;     // SOM/EOM/TO/Tag
    initializeBuffer(&test_5pkt_64B_good[2].packetBuffer[4], 64, 0x33, 1);  // Payload
    test_5pkt_64B_good[2].packetBuffer[68]  = MCTP_CalculateCRC8(test_5pkt_64B_good[2].packetBuffer, 68);     // PEC CRC-8
    
    // Packet 4
    test_5pkt_64B_good[3].packetBufferLength = 69;
    test_5pkt_64B_good[3].packetBuffer[0]   = 0x02;     // Header
    test_5pkt_64B_good[3].packetBuffer[1]   = 0x33;     // Dest EID
    test_5pkt_64B_good[3].packetBuffer[2]   = 0x44;     // Src EID
    test_5pkt_64B_good[3].packetBuffer[3]   = 0x3E;     // SOM/EOM/TO/Tag
    initializeBuffer(&test_5pkt_64B_good[3].packetBuffer[4], 64, 0x44, 1);  // Payload
    test_5pkt_64B_good[3].packetBuffer[68]  = MCTP_CalculateCRC8(test_5pkt_64B_good[3].packetBuffer, 68);     // PEC CRC-8
    
    // Packet 5 - 30 bytes payload
    test_5pkt_64B_good[4].packetBufferLength = 37;
    test_5pkt_64B_good[4].packetBuffer[0]   = 0x02;     // Header
    test_5pkt_64B_good[4].packetBuffer[1]   = 0x33;     // Dest EID
    test_5pkt_64B_good[4].packetBuffer[2]   = 0x44;     // Src EID
    test_5pkt_64B_good[4].packetBuffer[3]   = 0x4E;     // SOM/EOM/TO/Tag
    initializeBuffer(&test_5pkt_64B_good[4].packetBuffer[4], 32, 0x55, 1);  // Payload
    test_5pkt_64B_good[4].packetBuffer[36]  = MCTP_CalculateCRC8(test_5pkt_64B_good[4].packetBuffer, 36);     // PEC CRC-8
    
    // Verify initialized packets
    printBuffer(test_5pkt_64B_good[0].packetBuffer, test_5pkt_64B_good[0].packetBufferLength);
    printBuffer(test_5pkt_64B_good[1].packetBuffer, test_5pkt_64B_good[1].packetBufferLength);
    printBuffer(test_5pkt_64B_good[2].packetBuffer, test_5pkt_64B_good[2].packetBufferLength);
    printBuffer(test_5pkt_64B_good[3].packetBuffer, test_5pkt_64B_good[3].packetBufferLength);
    printBuffer(test_5pkt_64B_good[4].packetBuffer, test_5pkt_64B_good[4].packetBufferLength);
}

#endif

/******************************************************************************/
/*************************** MCTP RECEIVE ROUTINES ****************************/
/******************************************************************************/

enum MCTP_ERROR MCTP_ReceptionStart(struct transport_packet *rawPacket)
{
    #if TEST_MODE

    // For testing purposes, start test timer
    TestTimer_Start();
    return SUCCESS;
    
    #else

    // Set up I3C_RX_DMA to receive MCTP packets
    enum I3C_TARGET_BUFFER_RECEIVE_ERROR status = MCTP_I3C_BufferReceive(rawPacket->packetBuffer, sizeof(rawPacket->packetBuffer));

    if(status != I3C_TARGET_BUFFER_RECEIVE_NO_ERROR) {
        printf("\t[START PACKET] ERROR: I3C Buffer Receive setup failed\r\n");
        return ERROR_I3C_RECEIVE;
    }
    
    // Enable on-shot ACK
    MCTP_I3C_NextPrivateTransactionACK();
    
    printf("\t[START PACKET] I3C Buffer Receive setup complete... ready to receive packet...\r\n");
    return SUCCESS;
    
    #endif
}

enum MCTP_ERROR MCTP_PacketDecode(struct transport_packet *rawPacket, struct mctp_packet *decodedPacket) 
{
    if(rawPacket->packetBufferLength < MCTP_PACKET_OVERHEAD) {
        printf("\t[DECODE PACKET] ERROR: Packet Length is %d\r\n", rawPacket->packetBufferLength);
        return ERROR_PACKET_INVALID;
    }
    
    // Check if packet is available
    if(!decodedPacket->packetEmpty) {
        printf("\t[DECODE PACKET] ERROR: Packet not available\r\n");
        return ERROR_PACKET_UNAVAILABLE;
    }
    
    // Acquire packet
    decodedPacket->packetEmpty = false;
    
    // Initialize and start CRC-8
    CRC_Initialize(CRC8_LEN, CRC8_POLY);
    CRC_StartCrc();
    
    printBuffer(rawPacket->packetBuffer, rawPacket->packetBufferLength);
    
    #if USE_PHY_ADDR_FOR_CRC8
    // Perform CRC on Address Header
    while(CRC_IsCrcBusy());
    CRC_WriteData((MCTP_I3C_AddressGet() << 1) & 0xFF);     // LSb=0 for write mode
    #endif

    // Byte 1 -- Reserved (4b) // Hdr version (4b)
    decodedPacket->headerVersion     = rawPacket->packetBuffer[0] & 0x0F;
    while(CRC_IsCrcBusy());
    CRC_WriteData(rawPacket->packetBuffer[0]);
    
    // Byte 2 -- Destination EID
    decodedPacket->destinationEID    = rawPacket->packetBuffer[1];
    while(CRC_IsCrcBusy());
    CRC_WriteData(rawPacket->packetBuffer[1]);
    
    // Byte 3 -- Source EID
    decodedPacket->sourceEID         = rawPacket->packetBuffer[2];
    while(CRC_IsCrcBusy());
    CRC_WriteData(rawPacket->packetBuffer[2]);
    
    // Byte 4 -- SOM/EOM/Seq/TO/Tag
    decodedPacket->startOfMessage    = (rawPacket->packetBuffer[3] & 0x80) >> 7;
    decodedPacket->endOfMessage      = (rawPacket->packetBuffer[3] & 0x40) >> 6;
    decodedPacket->packetSequence    = (rawPacket->packetBuffer[3] & 0x30) >> 4;
    decodedPacket->tagOwner          = (rawPacket->packetBuffer[3] & 0x08) >> 3;
    decodedPacket->messageTag        = (rawPacket->packetBuffer[3] & 0x07);
    while(CRC_IsCrcBusy());
    CRC_WriteData(rawPacket->packetBuffer[3]);
    
    // Bytes 5+ -- Packet Payload
    uint16_t indexRawPacket = 4;
    uint16_t indexDecodedPacket = 0;  
    while(indexRawPacket < rawPacket->packetBufferLength - 1) {
        decodedPacket->packetPayload[indexDecodedPacket++] = rawPacket->packetBuffer[indexRawPacket];
        while(CRC_IsCrcBusy());
        CRC_WriteData(rawPacket->packetBuffer[indexRawPacket++]);
    }
    decodedPacket->packetPayloadLength = indexDecodedPacket;
    
    // Last Byte -- PEC (CRC8)
    decodedPacket->crc8Value = rawPacket->packetBuffer[indexRawPacket];
    while(CRC_IsCrcBusy());
    CRC_WriteData(rawPacket->packetBuffer[indexRawPacket]);
    
    if((uint8_t)(CRC_GetCalculatedResult(0,0)) != 0) {
        printf("\t[DECODE PACKET] ERROR: Incorrect CRC-8\r\n");
        //return ERROR_INCORRECT_CRC;
    }
    
    // Print decoded packet
    printPacket(decodedPacket);
    
    // Success
    return SUCCESS;
}

enum MCTP_ERROR MCTP_MessageAssemble(struct mctp_packet *packet, struct mctp_message *message) 
{    
    printf("\t[MCTP ASSEMBLY] Enter \r\n");
    
    // If message breakdown is in progress, then report error
    if(message->breakdownInProgress){
        printf("\t[MCTP ASSEMBLY] Error: Invalid Message Token\r\n");
        return ERROR_MSG_INVALID;
    }
    
    // Check if assembly is not in progress
    // meaning this is the first packet in the message
    if(!message->assemblyInProgress) 
    {
        // Verify that this is the first packet
        if(!packet->startOfMessage) {
            printf("\t[MCTP ASSEMBLY] Error: Packet is not start of message\r\n");
            return ERROR_PACKET_UNEXPECTED;
        }
        
        // Check if message token is available
        if(!message->messageEmpty) {
            printf("\t[MCTP ASSEMBLY] Error: Message token is not available\r\n");
            return ERROR_MSG_UNAVAILABLE;
        }
        
        // Acquire Message token
        message->messageEmpty = false;
        
        printf("\t[MCTP ASSEMBLY] Assembly begins with first packet >>>\r\n");
        
        // Assign basic message info
        message->headerVersion      = packet->headerVersion;
        message->destinationEID     = packet->destinationEID;
        message->sourceEID          = packet->sourceEID;
        message->tagOwner           = packet->tagOwner;
        message->messageTag         = packet->messageTag;
        
        // Assign internal variables
        message->lastPacketSequence = packet->packetSequence;
        message->assemblyInProgress = true;
        
        // Extract integrity check and message type
        message->integrityCheck     = (packet->packetPayload[0] & 0x80) >> 7;
        message->messageType        = (packet->packetPayload[0] & 0x7F);
    }
    
    // Or else, assembly is already in progress
    // meaning this is NOT the first packet in the message
    else
    {
        // Verify that this is NOT the first packet
        if(packet->startOfMessage) {
            printf("\t[MCTP ASSEMBLY] Error: Packet is start of message\r\n");
            return ERROR_PACKET_UNEXPECTED;
        }
        
        // Verify that basic message info matches
        if( (message->headerVersion != packet->headerVersion)   ||
            (message->destinationEID != packet->destinationEID) ||
            (message->sourceEID != packet->sourceEID)           ||
            (message->tagOwner != packet->tagOwner)             ||
            (message->messageTag != packet->messageTag) )
        {
            printf("\t[MCTP ASSEMBLY] Error: Basic info doesn't match\r\n");
            return ERROR_PACKET_UNEXPECTED;
        }
        
        // Verify that the packet sequence is correct
        message->lastPacketSequence = (message->lastPacketSequence + 1) & 0x03;   // mod 4
        if(message->lastPacketSequence != packet->packetSequence) {
            printf("\t[MCTP ASSEMBLY] Error: Packet is out of sequence\r\n");
            return ERROR_PACKET_UNEXPECTED;
        }
    }
    
    // Define index variables for copying packet payload to message body
    uint16_t indexPayload = 0;
    uint16_t indexMessage = message->messageBodyLength;     // concatenate to existing message body
    
    // Update the message length first and check for size limits
    message->messageBodyLength += packet->packetPayloadLength;
    if(message->messageBodyLength > MCTP_MAX_MESSAGE_SIZE) {
        printf("\t[MCTP ASSEMBLY] Max Message Size length exceeded\r\n");
        return ERROR_MSG_SIZE_EXCEEDED;
    }
    
    // Copy packet payload to message
    while(indexPayload < packet->packetPayloadLength) {
        message->messageBody[indexMessage++] = packet->packetPayload[indexPayload++];
    }
    
    // Now check if this is the last packet
    if(packet->endOfMessage)
    {
        // Extract CRC-32C
        message->crc32Value |= (((uint32_t)message->messageBody[indexMessage-1]) << 24);
        message->crc32Value |= (((uint32_t)message->messageBody[indexMessage-2]) << 16);
        message->crc32Value |= (((uint32_t)message->messageBody[indexMessage-3]) << 8);
        message->crc32Value |= (((uint32_t)message->messageBody[indexMessage-4]));
        
        // If this is the last packet, finish assembly and return SUCCESS
        message->assemblyInProgress = false;
        
        // Discard packet
        packet->packetEmpty = true;
        
        // Print assembled message
        printMessage(message);

        printf("\t[MCTP ASSEMBLY] Assembly complete with last packet <<<\r\n");
        return SUCCESS;
    }
    
    // Not the last packet
    else
    {
        // Discard packet
        packet->packetEmpty = true;
        
        // If this is not the last packet, then return IN_PROGRESS
        printf("\t[MCTP ASSEMBLY] Assembly in progress, awaiting more packets ...\r\n");
        return IN_PROGRESS;
    }
    
}

enum MCTP_ERROR MCTP_MessageDecipher (struct mctp_message *message)
{
    // Verify CRC-32C
    CRC_Initialize(CRC32C_LEN, 0x04C11DB7);
    CRC_StartCrc();
    
    uint16_t indexMessage = 0;
    
    while(indexMessage < message->messageBodyLength-4)
    {
        while(CRCCON0bits.FULL);
        CRCDATAT = message->messageBody[indexMessage];
        CRCDATAU = message->messageBody[indexMessage+1];
        CRCDATAH = message->messageBody[indexMessage+2];
        CRCDATAL = message->messageBody[indexMessage+3];
        
        //printf("%08lX ", CRCDATA);
        indexMessage += 4;
        
        // Check if message size is not divisible by 4
    }
    
    printf("\r\n\t[DECIPHER MESSAGE] Calculated CRC-32C: 0x%08lX\r\n", CRC_GetCalculatedResult(0,0xFFFFFFFF));
    
}

/******************************************************************************/
/************************* MCTP TRANSMIT ROUTINES *****************************/
/******************************************************************************/

enum MCTP_ERROR MCTP_MessagePackage(struct mctp_message *message)
{
    // Package message
    
    // For testing, echo back received message
    txMessage = rxMessage;
    txMessage.assemblyInProgress = false;
    txMessage.breakdownInProgress = false;
    txMessage.messageEmpty = false;
    
    return SUCCESS;
}

enum MCTP_ERROR MCTP_MessageBreakdown(struct mctp_message *message, struct mctp_packet *packet)
{
    printf("\t[MCTP BREAKDOWN] Enter \r\n");
    
    // If message assembly is in progress or message token is empty, then report error
    if(message->assemblyInProgress || message->messageEmpty)
    {
        printf("\t[MCTP BREAKDOWN] Error: Invalid Message Token\r\n");
        return ERROR_MSG_INVALID;
    }
    
    // Check if packet is empty and available
    if(!packet->packetEmpty) {
        printf("\t[MCTP BREAKDOWN] Error: Packet is not available\r\n");
        return ERROR_PACKET_UNAVAILABLE;
    }
    
    // Acquire packet
    packet->packetEmpty = false;
    
    // Add basic packet headers
    packet->headerVersion       = message->headerVersion;
    packet->destinationEID      = message->destinationEID;
    packet->sourceEID           = message->sourceEID;
    packet->tagOwner            = message->tagOwner;
    packet->messageTag          = message->messageTag;
    
    // Add packet sequence
    packet->packetSequence      = (message->lastPacketSequence+1) & 0x03;
    message->lastPacketSequence = packet->packetSequence;
    
    // Assign start/end of message to false as default (will be changed later)
    packet->startOfMessage = false;
    packet->endOfMessage = false;
    
    // Check if breakdown is not in progress
    // meaning this is the first packet in the message
    if(!message->breakdownInProgress)
    {
        // Start breakdown
        message->breakdownInProgress = true;
        
        // Add start of message flag
        packet->startOfMessage = true;
        
        // Start packet sequence from 0
        packet->packetSequence = 0;
        message->lastPacketSequence = 0;
        
        // Start copying message data from the top
        message->nextMessageBodyIndex = 0;
    }
    
    // No need to copy integrity check, message type, crc32 separately
    // since they are part of the message body anyway
    
    // Define index variables for copying message body into packet payload
    uint16_t indexPayload = 0;
    uint16_t indexMessage = message->nextMessageBodyIndex;
    
    // Specify payload length
    packet->packetPayloadLength = MCTP_TransmissionSizeGet();   // min 64 bytes as per MCTP spec
    
    // Copy message to payload
    while(indexPayload < packet->packetPayloadLength) {
        packet->packetPayload[indexPayload++] = message->messageBody[indexMessage++];
        
        // Check if message body is over
        // meaning this is the last packet to be transmitted
        if(indexMessage >= message->messageBodyLength) 
        {
            // Update payload length for last packet
            packet->packetPayloadLength = indexPayload;
            
            // Specify end of message
            packet->endOfMessage = true;
            
            // Break out of this loop
            break;
        }
    }
    
    // Update next message body index
    message->nextMessageBodyIndex = indexMessage;
    
    // Assign CRC8 value
    packet->crc8Value = 0xC8;   // Needs to be calculated
    
    // Print packet
    printPacket(&transmitPacket);
    
    // If this is the last packet, do message clean up
    if(packet->endOfMessage)
    {
        // Complete breakdown and release message token
        message->breakdownInProgress = false;
        message->messageEmpty = true;
        
        printf("\t[MCTP BREAKDOWN] Breakdown complete with last packet <<<\r\n");
        return SUCCESS;
    }
    
    // Not the last packet
    else
    {
        printf("\t[MCTP BREAKDOWN] Breakdown in progress, more packets to be sent ...\r\n");
        return IN_PROGRESS;
    }
}

enum MCTP_ERROR MCTP_PacketEncode(struct mctp_packet *packetToEncode, struct transport_packet *rawPacket)
{
    // Check if transport packet is empty and available
    if(!rawPacket->packetEmpty) {
        printf("\t[MCTP ENCODE] Error: Transport Packet is not available\r\n");
        return ERROR_PACKET_UNAVAILABLE;
    }
    
    // Check if transport packet is long enough for the data packet
    if(packetToEncode->packetPayloadLength > MCTP_MAX_PACKET_SIZE) {
        printf("\t[MCTP ENCODE] Error: Packet too long\r\n");
        return ERROR_PACKET_INVALID;
    }
    
    // Acquire transport packet
    rawPacket->packetEmpty = false;
    
    // Initialize and start CRC-8
    CRC_Initialize(CRC8_LEN, CRC8_POLY);
    CRC_StartCrc();
    
    #if USE_PHY_ADDR_FOR_CRC8
    // Perform CRC on Address Header
    while(CRC_IsCrcBusy());
    CRC_WriteData(((MCTP_I3C_AddressGet() << 1) & 0xFF) | 0x01);    // LSb=1 for read mode
    #endif
    
    // Byte 1 -- Reserved (4b) // Hdr version (4b)
    rawPacket->packetBuffer[0] = packetToEncode->headerVersion & 0x0F;
    while(CRC_IsCrcBusy());
    CRC_WriteData(rawPacket->packetBuffer[0]);
    
    // Byte 2 -- Destination EID
    rawPacket->packetBuffer[1] = packetToEncode->destinationEID;
    while(CRC_IsCrcBusy());
    CRC_WriteData(rawPacket->packetBuffer[1]);
    
    // Byte 3 -- Source EID
    rawPacket->packetBuffer[2] = packetToEncode->sourceEID;
    while(CRC_IsCrcBusy());
    CRC_WriteData(rawPacket->packetBuffer[2]);
    
    // Byte 4 -- SOM/EOM/Seq/TO/Tag
    rawPacket->packetBuffer[3]  = (packetToEncode->startOfMessage << 7) & 0x80;
    rawPacket->packetBuffer[3] |= (packetToEncode->endOfMessage   << 6) & 0x40;
    rawPacket->packetBuffer[3] |= (packetToEncode->packetSequence << 4) & 0x30;
    rawPacket->packetBuffer[3] |= (packetToEncode->tagOwner       << 3) & 0x08;
    rawPacket->packetBuffer[3] |= (packetToEncode->messageTag         ) & 0x07;
    while(CRC_IsCrcBusy());
    CRC_WriteData(rawPacket->packetBuffer[3]);
    
    // Bytes 5+ -- Packet Payload
    uint16_t indexRawPacket = 4;
    uint16_t indexPacketToEncode = 0;  
    while(indexPacketToEncode < packetToEncode->packetPayloadLength) {
        rawPacket->packetBuffer[indexRawPacket] = packetToEncode->packetPayload[indexPacketToEncode++];
        while(CRC_IsCrcBusy());
        CRC_WriteData(rawPacket->packetBuffer[indexRawPacket++]);
    }
    
    // Last Byte -- PEC (CRC8)
    rawPacket->packetBuffer[indexRawPacket++] = CRC_GetCalculatedResult(false, 0) & 0xFF;
    
    // Assign packet length
    rawPacket->packetBufferLength = indexRawPacket;
    
    // Print encoded packet
    printBuffer(rawPacket->packetBuffer, rawPacket->packetBufferLength);
    
    // Assign internal variables
    rawPacket->firstPacket = packetToEncode->startOfMessage;
    rawPacket->lastPacket = packetToEncode->endOfMessage;
    
    // Discard packet that was just encoded
    packetToEncode->packetEmpty = true;
    
    return SUCCESS;
}

enum MCTP_ERROR MCTP_PacketSend(struct transport_packet *rawPacket)
{
    enum I3C_TARGET_BUFFER_TRANSMIT_ERROR status = MCTP_I3C_BufferTransmit(rawPacket->packetBuffer, rawPacket->packetBufferLength);
    
    if(status != I3C_TARGET_BUFFER_TRANSMIT_NO_ERROR) {
        printf("\t[MCTP SEND] ERROR: I3C Buffer Transmit setup failed\r\n");
        return ERROR_I3C_TRANSMIT;
    }
    
    // Enable one-shot ACK (for rev C0+)
    //MCTP_I3C_NextPrivateTransactionACK();
    
    // If first packet
    if(rawPacket->firstPacket){
        printf("\t[MCTP SEND] First packet.\r\n");
        
        // Send IBI
        MCTP_I3C_IBIRequestNoPayload();
    }
    
    // If last packet
    if(rawPacket->lastPacket){
        printf("\t[MCTP SEND] Last packet.\r\n");
    }
    
    printf("\t[MCTP SEND] I3C Buffer Transmit setup complete... ready to send packet...\r\n");
    return SUCCESS;
}

enum MCTP_ERROR MCTP_SentPacketDiscard(struct transport_packet *rawPacket)
{
    // Discard transport packet
    rawPacket->packetEmpty = true;
    
    // If last packet, then return a successful completion of message breakdown
    if(rawPacket->lastPacket) {
        return SUCCESS;
    }
    
    // Otherwise return message breakdown is still in progress
    else {
        return IN_PROGRESS;
    }
    
    // No error needs to be returned since error is already reported in RxTxComplete_ISR
}

/******************************************************************************/
/************* PACKET RX/TX COMPLETE FOR TX/RX STATE MACHINES *****************/
/******************************************************************************/

void MCTP_PacketRxTxComplete_ISR(struct I3C_TARGET_TRANSACTION_COMPLETE_STATUS *transactionCompleteStatus)
{
    if(transactionCompleteStatus->dataFlowDirection == I3C_TARGET_DATA_RECEIVED) 
    {
        // Transport Packet Received in rxTransportPacket.packetBuffer[]
        rxTransportPacket.packetBufferLength = transactionCompleteStatus->numOfBytesReceived;
        
        // Change state to packet decode
        mctp_rx_state.changeState = true;
        mctp_rx_state.nextState = STATE_RX_PACKET_DECODE;
        
        // No printf here since this is an ISR callback
    }
    else
    {
        // Transport Packet Sent
        
        // Change state to packet discard
        mctp_tx_state.changeState = true;
        mctp_tx_state.nextState = STATE_TX_PACKET_DISCARD;
        
        // No printf here since this is an ISR callback
    }
}

/******************************************************************************/
/******************************** RX STATE MACHINES ***************************/
/******************************************************************************/

// This timer ISR is used to trigger a packet received every N seconds (N = 5s?)
void Timed_Packet_Receive_ISR(void)
{
    // Check if state is waiting to receive packets
    if(mctp_rx_state.currentState != STATE_RX_PACKET_RECEIVE_WAIT) {
        return;
    }
        
    static uint8_t count = 0;

    #if TEST_MODE
    rxTransportPacket = test_5pkt_64B_good[count++];     // Update pointer to received packet
    
    if(count > 5) {
        count = 0;
        TestTimer_Stop();
    }
    #endif
    
    // Change state to packet decode
    mctp_rx_state.changeState = true;
    mctp_rx_state.nextState = STATE_RX_PACKET_DECODE;
    
    // No printf here since this is an ISR callback
}

void MCTP_RX_Start(void) 
{    
    if(mctp_reception_begin)
    {
        // Trigger Start by arming I3C1 RX DMA

        enum MCTP_ERROR status = MCTP_ReceptionStart(&rxTransportPacket);
        
        if(status != SUCCESS) {
            // Change to Error state
            mctp_rx_state.changeState = true;
            mctp_rx_state.nextState = STATE_RX_ERROR;
            printf("[STATE_RX_START] ERROR. Changing to STATE_RX_ERROR\r\n");
            return;
        }

        // Change state to wait for receiving packets
        mctp_rx_state.changeState = true;
        mctp_rx_state.nextState = STATE_RX_PACKET_RECEIVE_WAIT;
        printf("[STATE_RX_START] Changing to STATE_RX_PACKET_RECEIVE_WAIT\r\n");
    }
}

void MCTP_RX_PacketDecode (void) 
{
    enum MCTP_ERROR status = MCTP_PacketDecode(&rxTransportPacket, &receivedPacket);
    
    if(status != SUCCESS) {
        // Change to Error state
        mctp_rx_state.changeState = true;
        mctp_rx_state.nextState = STATE_RX_ERROR;
        printf("[STATE_RX_PACKET_DECODE] ERROR. Changing to STATE_RX_ERROR\r\n");
        return;
    }
    
    // Change state here or in the other function?
    mctp_rx_state.changeState = true;
    mctp_rx_state.nextState = STATE_RX_MESSAGE_ASSEMBLE;
    printf("[STATE_RX_PACKET_DECODE] Changing to STATE_RX_MESSAGE_ASSEMBLE\r\n");

}

void MCTP_RX_MessageAssemble(void) 
{
    enum MCTP_ERROR status = MCTP_MessageAssemble(&receivedPacket, &rxMessage);
    
    // Returned: Assembly still in progress
    if(status == IN_PROGRESS)
    {
        printf("[STATE_RX_MESSAGE_ASSEMBLE] Changing to STATE_RX_START\r\n");
        
        // Go back to receiving more packets
        mctp_rx_state.changeState = true;
        mctp_rx_state.nextState = STATE_RX_START;
        return;
    }
    
    // Returned: Assembly complete
    else if(status == SUCCESS)
    {
        printf("[STATE_RX_MESSAGE_ASSEMBLE] Changing to STATE_RX_MESSAGE_DECIPHER\r\n");
        
        // Go to decipher message state
        mctp_rx_state.changeState = true;
        mctp_rx_state.nextState = STATE_RX_MESSAGE_DECIPHER;
        return;
    }
    
    // Returned: Error
    else
    {
        printf("[STATE_RX_MESSAGE_ASSEMBLE] ERROR. Changing to STATE_RX_ERROR\r\n");
        
        // Change to Error state
        mctp_rx_state.changeState = true;
        mctp_rx_state.nextState = STATE_RX_ERROR;
        return;
    }
    
}

void MCTP_RX_MessageDecipher(void)
{
    
    enum MCTP_ERROR status = MCTP_MessageDecipher(&rxMessage);
    
    // Change to Error state
    mctp_rx_state.changeState = true;
    mctp_rx_state.nextState = STATE_RX_ACTION;
    printf("[STATE_RX_MESSAGE_DECIPHER] Changing to STATE_RX_ACTION\r\n");

}

void MCTP_RX_Action(void) 
{
    mctp_transmission_begin = true;
    mctp_reception_begin = false;
    
    // Change to Start state
    mctp_rx_state.changeState = true;
    mctp_rx_state.nextState = STATE_RX_START;
    printf("[STATE_RX_ACTION] Changing to STATE_RX_START\r\n");
    
}

void MCTP_RX_Error(void)
{
    // Discard the message/packet and return to start
    printf("[STATE_RX_ERROR] Discarding packet/message received... Starting brand new reception...\r\n");
    
    // Discard message
    rxMessage.assemblyInProgress = false;
    rxMessage.breakdownInProgress = false;
    rxMessage.messageEmpty = true;
    
    // Discard packet
    receivedPacket.packetEmpty = true;
        
    // Change to Start state
    mctp_rx_state.changeState = true;
    mctp_rx_state.nextState = STATE_RX_START;
    printf("[STATE_RX_ERROR] Changing to STATE_RX_START\r\n");
    
}

void MCTP_RECEPTION_StateMachine(void) {
    switch(mctp_rx_state.currentState)
    {
        case STATE_RX_START:
            MCTP_RX_Start();
            break;
            
        case STATE_RX_PACKET_RECEIVE_WAIT:
            // This is a wait state, do nothing here
            // State change happens from RxTxComplete_ISR
            break;
            
        case STATE_RX_PACKET_DECODE:
            MCTP_RX_PacketDecode();
            break;
            
        case STATE_RX_MESSAGE_ASSEMBLE:
            MCTP_RX_MessageAssemble();
            break;
            
        case STATE_RX_MESSAGE_DECIPHER:
            MCTP_RX_MessageDecipher();
            break;
            
        case STATE_RX_ACTION:
            MCTP_RX_Action();
            break;
            
        case STATE_RX_ERROR:
            MCTP_RX_Error();
            
        default:
            break;
            
    }
    
    // Change state
    if(mctp_rx_state.changeState) {
        printf("[MCTP RX] State Changed --------------------\r\n\n");
        mctp_rx_state.previousState = mctp_rx_state.currentState;
        mctp_rx_state.currentState = mctp_rx_state.nextState;
        mctp_rx_state.nextState = 0;
        mctp_rx_state.changeState = false;
    }
}

/******************************************************************************/
/******************************** TX STATE MACHINES ***************************/
/******************************************************************************/

void MCTP_TX_Start(void) 
{
    // When the trigger happens, switch to next state
    if(mctp_transmission_begin)
    {
        mctp_transmission_begin = false;
        
        // Change state to start packaging message for transmission
        printf("[STATE_TX_START] Changing to STATE_TX_MESSAGE_PACKAGE\r\n");
        mctp_tx_state.changeState = true;
        mctp_tx_state.nextState = STATE_TX_MESSAGE_PACKAGE;
        return;
    }
}

void MCTP_TX_MessagePackage(void) 
{
    enum MCTP_ERROR status = MCTP_MessagePackage(&txMessage);
    
    if(status == SUCCESS)
    {
        // Change state to start breaking message intp packets for transmission
        printf("[STATE_TX_MESSAGE_PACKAGE] Changing to STATE_TX_MESSAGE_BREAKDOWN\r\n");
        mctp_tx_state.changeState = true;
        mctp_tx_state.nextState = STATE_TX_MESSAGE_BREAKDOWN;
        return;
    }
    else
    {
        printf("[STATE_TX_MESSAGE_PACKAGE] ERROR. Changing to STATE_TX_ERROR\r\n");
        
        // Change to Error state
        mctp_tx_state.changeState = true;
        mctp_tx_state.nextState = STATE_TX_ERROR;
        return;
    }
    
    
}

void MCTP_TX_MessageBreakdown(void)
{
    enum MCTP_ERROR status = MCTP_MessageBreakdown(&txMessage, &transmitPacket);
    
    // Returned: Breakdown still in progress or successfully completed
    if(status == IN_PROGRESS || status == SUCCESS)
    {
        printf("[STATE_TX_MESSAGE_BREAKDOWN] Changing to STATE_TX_PACKET_ENCODE\r\n");
        
        // Change state to start encoding the packets for transmission
        mctp_tx_state.changeState = true;
        mctp_tx_state.nextState = STATE_TX_PACKET_ENCODE;
        return;
    }

    // Returned: Error
    else
    {
        printf("[STATE_TX_MESSAGE_BREAKDOWN] ERROR. Changing to STATE_TX_ERROR\r\n");
        
        // Change to Error state
        mctp_tx_state.changeState = true;
        mctp_tx_state.nextState = STATE_TX_ERROR;
        return;
    }
}

void MCTP_TX_PacketEncode(void) 
{
    enum MCTP_ERROR status = MCTP_PacketEncode(&transmitPacket, &txTransportPacket);
    
    if(status == SUCCESS)
    {
        // Change state to start transmission of encoded packet using I3C
        printf("[STATE_TX_PACKET_ENCODE] Changing to STATE_TX_PACKET_SEND\r\n");
        mctp_tx_state.changeState = true;
        mctp_tx_state.nextState = STATE_TX_PACKET_SEND;
        return;
    }
    else
    {
        printf("[STATE_TX_PACKET_ENCODE] ERROR. Changing to STATE_TX_ERROR\r\n");
        
        // Change to Error state
        mctp_tx_state.changeState = true;
        mctp_tx_state.nextState = STATE_TX_ERROR;
        return;
    }
    
    
}

void MCTP_TX_PacketSend(void) 
{
    enum MCTP_ERROR status = MCTP_PacketSend(&txTransportPacket);
    
    if(status == SUCCESS)
    {
        // Change state to wait state for sending data
        printf("[STATE_TX_PACKET_SEND] Changing to STATE_TX_PACKET_SEND_WAIT\r\n");
        mctp_tx_state.changeState = true;
        mctp_tx_state.nextState = STATE_TX_PACKET_SEND_WAIT;
        return;
    }
    else
    {
        printf("[STATE_TX_PACKET_SEND] ERROR. Changing to STATE_TX_ERROR\r\n");
        
        // Change to Error state
        mctp_tx_state.changeState = true;
        mctp_tx_state.nextState = STATE_TX_ERROR;
        return;
    }
}

void MCTP_TX_PacketDiscard(void)
{
    enum MCTP_ERROR status = MCTP_SentPacketDiscard(&txTransportPacket);
    
    // Returned: Breakdown still in progress, more packets are expected
    if(status == IN_PROGRESS)
    {
        printf("[STATE_TX_PACKET_DISCARD] Changing to STATE_TX_MESSAGE_BREAKDOWN\r\n");
        
        // Go back to breaking down message into more packets
        mctp_tx_state.changeState = true;
        mctp_tx_state.nextState = STATE_TX_MESSAGE_BREAKDOWN;
        return;
    }
    
    // Returned: All packets have been sent
    else if(status == SUCCESS)
    {
        printf("[STATE_TX_PACKET_DISCARD] Changing to STATE_TX_START\r\n");
        
        // Go back to start state
        mctp_tx_state.changeState = true;
        mctp_tx_state.nextState = STATE_TX_START;
        return;
    }
    
    // Returned: Error
    else
    {
        printf("[STATE_TX_PACKET_DISCARD] ERROR. Changing to STATE_TX_ERROR\r\n");
        
        // Change to Error state
        mctp_tx_state.changeState = true;
        mctp_tx_state.nextState = STATE_TX_ERROR;
        return;
    }
}

void MCTP_TX_Action(void) {}

void MCTP_TX_Error(void) 
{
    // Discard the message/packet and return to start
    printf("[STATE_TX_ERROR] Discarding packet/message...\r\n");
    
    // Discard message
    txMessage.assemblyInProgress = false;
    txMessage.breakdownInProgress = false;
    txMessage.messageEmpty = true;
    
    // Discard packet
    transmitPacket.packetEmpty = true;
        
    // Change to Start state
    mctp_tx_state.changeState = true;
    mctp_tx_state.nextState = STATE_TX_START;
    printf("[STATE_TX_ERROR] Changing to STATE_TX_START\r\n");
}

void MCTP_TRANSMISSION_StateMachine(void) {
    switch(mctp_tx_state.currentState)
    {
        case STATE_TX_START:
            MCTP_TX_Start();
            break;
            
        case STATE_TX_MESSAGE_PACKAGE:
            MCTP_TX_MessagePackage();
            break;
            
        case STATE_TX_MESSAGE_BREAKDOWN:
            MCTP_TX_MessageBreakdown();
            break;
            
        case STATE_TX_PACKET_ENCODE:
            MCTP_TX_PacketEncode();
            break;
            
        case STATE_TX_PACKET_SEND:
            MCTP_TX_PacketSend();
            break;
            
        case STATE_TX_PACKET_SEND_WAIT:
            // This is a wait state, do nothing here
            // State change happens from RxTxComplete_ISR
            break;
            
        case STATE_TX_PACKET_DISCARD:
            MCTP_TX_PacketDiscard();
            break;
            
        case STATE_TX_ACTION:
            MCTP_TX_Action();
            break;
            
        case STATE_TX_ERROR:
            MCTP_TX_Error();
            
        default:
            break;
            
    }
    
    // Change state
    if(mctp_tx_state.changeState) {
        printf("[MCTP TX] State Changed --------------------\r\n\n");
        mctp_tx_state.previousState = mctp_tx_state.currentState;
        mctp_tx_state.currentState = mctp_tx_state.nextState;
        mctp_tx_state.nextState = 0;
        mctp_tx_state.changeState = false;
    }
}

////////////////////////////////////////////////////////////////////////////////
// INITIALIZATION ROUTINES //
////////////////////////////////////////////////////////////////////////////////


enum MCTP_ERROR MCTP_Initialize(void) {
    // Register all interrupt callbacks
    TU16A_PRMatchInterruptHandlerSet(Timed_Packet_Receive_ISR);     // For TEST_MODE
    MCTP_I3C_TransactionCompleteCallbackRegister(MCTP_PacketRxTxComplete_ISR);
    
    // Initialize reception state machine
    mctp_rx_state.currentState = STATE_RX_START;
    mctp_rx_state.nextState = 0;
    mctp_rx_state.previousState = 0;
    mctp_rx_state.changeState = false;
    
    // Initialize transmission state machine
    mctp_tx_state.currentState = STATE_TX_START;
    mctp_tx_state.nextState = 0;
    mctp_tx_state.previousState = 0;
    mctp_tx_state.changeState = false;
    
    // Initialize global packets
    receivedPacket.packetEmpty = true;
    transmitPacket.packetEmpty = true;
    txTransportPacket.packetEmpty = true;
    rxTransportPacket.packetEmpty = true;  
    
    // Initialize global message tokens
    rxMessage.messageEmpty = true;
    rxMessage.assemblyInProgress = false;
    rxMessage.breakdownInProgress = false;
    txMessage.messageEmpty = true;
    txMessage.assemblyInProgress = false;
    txMessage.breakdownInProgress = false;
    
    
    
    // Initialize transmission and reception
    mctp_transmission_begin = false;
    mctp_reception_begin = true;
    
    #if TEST_MODE
    // Initialize test transport packets
    test_5pkt_64B_good_initialize();
    
    // If in test mode, then exit here before Hot-Join is performed
    return SUCCESS;
    #endif
    
    // HOT-JOIN (BLOCKING IMPLEMENTATION)
    
    // Request for a Hot-Join
    printf("[MCTP INITIALIZE] Requesting Hot-Join...\r\n");
    if(MCTP_I3C_HotJoinRequest() != I3C_TARGET_HJ_REQUEST_NO_ERROR) {
        printf("[MCTP INITIALIZE] ERROR. Hot-Join Request cannot be made\r\n");
        return ERROR_I3C_HOTJOIN;
    }
    
    // Wait for Hot-Join to complete (Blocking)
    while(MCTP_I3C_HotJoinStatusGet() == I3C_TARGET_HJ_PENDING);
    
    // Check for Hot-Join Error
    if(MCTP_I3C_HotJoinErrorGet()) {
        printf("[MCTP INITIALIZE] ERROR. Hot-Join Error. Retry limit exceeded\r\n");
        return ERROR_I3C_HOTJOIN;
    }
    
    printf("[MCTP INITIALIZE] Hot-Join completed successfully with Dyn Addr = 0x%02hhX\r\n", MCTP_I3C_AddressGet());
    
    return SUCCESS;
}



/*
    Main application
*/

int main(void)
{
    SYSTEM_Initialize();
    MCTP_Initialize();

    // Enable the Global High Interrupts 
    INTERRUPT_GlobalInterruptHighEnable(); 
    
    // Enable Timer and such
    
    //TestTimer_Start();

    
    printf("\r\n\r\n---[MAIN]---\r\n");
    
    
    struct transport_packet rawPacket1 = {
        {
            0xF1, 0x65, 0x32, 0xAA, 0x84, 0x90, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x41, 0x5A, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36,
            0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
            0x20, 0x20, 0x20, 0x20, 0x7A, 0x1F, 0xC4, 0x7B,
            0x48
        },
        49
    };
    
    //struct mctp_packet decodedPacket1;
    //MCTP_PacketDecode(&rawPacket1, &decodedPacket1);
    
    // Verify CRC-32C
    uint8_t buf[] = {0x84, 0x00, 0x00, 0x00, 0x04, 0x45, 0x00, 0x00};
    CRC_Initialize(CRC32C_LEN, 0x04C11DB7);
    CRC_StartCrc();
    
    CRCDATA = 0xFFFFFFFF;
    
    uint16_t i = 0;
    
    while(i < sizeof(buf))
    {
        while(CRCCON0bits.BUSY);
        while(CRCCON0bits.FULL);
        CRCDATAT = buf[i+3];
        CRCDATAU = buf[i+2];
        CRCDATAH = buf[i+1];
        CRCDATAL = buf[i];
        
        printf("0x%08lX ", CRCDATA);
        i += 4;
        
        // Check if message size is not divisible by 4
    }
    
    printf("Calculated CRC-32C: 0x%08lX\r\n", CRC_GetCalculatedResult(0,0xFFFFFFFF));
    
    
    printf("[MAIN] Entering while 1...\r\n");
    while(1)
    {
        MCTP_RECEPTION_StateMachine();
        MCTP_TRANSMISSION_StateMachine();
        //printf("[MAIN WHILE 1]\r\n");
        //__delay_ms(500);
    }    
}